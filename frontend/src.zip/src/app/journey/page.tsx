import { redirect } from "next/navigation";

export default function JourneyIndexPage() {
  redirect("/journey/orientasi");
}